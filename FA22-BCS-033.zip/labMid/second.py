
while True:
    userInput = input("Enter 'q' or 'quit' to exit: ")
    if userInput== 'q' or userInput == 'quit':
        break
    else:
        print("You entered:", userInput)