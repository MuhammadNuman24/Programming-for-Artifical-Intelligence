name = input("Enter your name: ")
prefix =f"FA22-{name}"
print(prefix)

